$(document).ready(function(){
    
    var loader = document.getElementById('chart-preloader');
    setTimeout(function(){
        loader.style.display = "none";
    },1000)
    $('canvas').hide()
    $('#myChart5').show()
    $('#c-btn1').click(function(){
        loader.style.display = 'flex'
        setTimeout(function(){
            loader.style.display = "none";
        },1000)
        $('canvas').hide()
        $('#myChart').show();
    })
    $('#c-btn2').click(function(){
        loader.style.display = 'flex'
        setTimeout(function(){
            loader.style.display = "none";
        },1000)
        $('canvas').hide()
        $('#myChart2').show();
        
    })
    $('#c-btn3').click(function(){
        loader.style.display = 'flex'
        setTimeout(function(){
            loader.style.display = "none";
        },1000)
        $('canvas').hide()
        $('#myChart3').show();
    })
    $('#c-btn4').click(function(){
        loader.style.display = 'flex'
        setTimeout(function(){
            loader.style.display = "none";
        },1000)
        $('canvas').hide()
        $('#myChart4').show();
    })
    $('#c-btn5').click(function(){
        loader.style.display = 'flex'
        setTimeout(function(){
            loader.style.display = "none";
        },1000)
        $('canvas').hide()
        $('#myChart5').show();
    })
    // $(window).scroll(function(){
    //     var scroll = $(window).scrollTop,
    //     dh =$(document).height(),
    //     wh =$(window).height();
    //     scrollPercent = (scroll / (dh-wh)) * 100;
    //     $('#scroll').css('height', scrollPercent + "%");
    // })

    ScrollReveal({
        reset:true,
        distance:'60px',
        duration:2500,
        delay:400
    });
    ScrollReveal().reveal('.fade-title',{delay:200, origin:'left'});
    ScrollReveal().reveal('.fade-left',{delay:200, origin:'left'});
    ScrollReveal().reveal('.fade-right',{delay:200, origin:'right'});
    ScrollReveal().reveal('.box-group',{delay:200});
    ScrollReveal().reveal('.bottom',{delay:200});

})
var typedjs = new Typed('#typed',{
    strings:['Welcome to Kelajak Academy!'],
    typeSpeed: 50,
    fadeOut: true,
    fadeOutClass: 'typed-fade-out',
    showCursor: false,
}) 
// var dreamjs = new Typed('#dream',{
//     strings:['by Dream Team Corp !'],
//     typeSpeed: 50,
//     fadeOut: true,
//     fadeOutClass: 'typed-fade-out',
//     showCursor: false,
// })
var typed = document.getElementById('preloader');
setTimeout(function(){
    typed.style.display = 'none';
},3500)